<?php
 require_once 'Instancia.php';
 $fut = formularioPersona::recuperarTodos();
?>
<?php

require_once 'instancia.php';

$persona=new formularioPersona('puterodevista', 'Mayha', 'Mayha', 'martha', 'yuliplay688@gmail.com', '181818', '525', '2022-10-09 00:00:00');
$persona-> guardar();
// echo $persona ->getNombre().' se ha guardado correctamente con el id:' .$persona ->getId();

?>



<html>
   <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="jquery.dynamicTable.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="style.css" type="text/css" rel="stylesheet">
    </head>
    
   <body>
    
   <!--
      <ul>
      <?php foreach($elformulario as $item): ?>
      <li> <?php echo $item['Id'] . ' - ' . $item['Nombre'] . ' - ' . $item['Apellido'] . ' - ' . $item['contacto'] . ' - ' . $item['correo'] . ' - ' . $item['contraseña'] . ' - ' . $item['perfil'] . ' - ' . $item['deben']; ?> </li>
      <?php endforeach; ?>
      </ul>
   -->
   

   <h4 class="titulo">PSICOLAB</h4>
   
   <div class="container">
   </div> 
    <div style="display:flex" class="tables" >
    <div class="firstTable">
    <section>
    <h2 id="tuclase">clientes</h2>
    </section>
     <table id="myTable" class="display" style="width:100%">
        <thead>
            <tr>
                <th  >Id</th>
                <th  >streaming</th>
                <th  >Nombre</th>
                <th  >Apellido</th>
                <th  >Contacto</th>
                <th  >correo</th>
                <th  >contraseña</th>
                <th  >perfil</th>
                <th  >deben</th>
                <th  >Apellido</th>                
            </tr>
        </thead>
        <tbody>
        <?php foreach($fut as $item): ?>
            <tr>
                <td ><?php echo $item['Id']?></td>
                <td ><?php echo $item['streaming']?></td>
                <td ><?php echo $item['Nombre']?></td>
                <td ><?php echo $item['Apellido']?></td>
                <td ><?php echo $item['contacto']?></td>
                <td ><?php echo $item['correo']?></td>
                <td ><?php echo $item['contraseña']?></td>
                <td ><?php echo $item['perfil']?></td>
                <td ><?php echo $item['deben']?></td>

            </tr>
         <?php endforeach; ?>
         </tbody>
        
    </table>
        
     </div>
</div>




        <script>
        $(document).ready( function () {
        $('#myTable').DataTable();
        $('#Table').DataTable();} );
        </script>






   </body>
</html>
