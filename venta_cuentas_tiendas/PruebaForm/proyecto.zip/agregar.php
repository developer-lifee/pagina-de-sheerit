<?php

require_once 'instancia2.php';
//Validamos que hayan llegado estas variables, y que no esten vacias:
if (isset($_POST["nombre"], $_POST["apellido"], $_POST["contacto"], $_POST["correo"], $_POST["contraseña"], $_POST["perfil"], $_POST["deben"])){

//traspasamos a variables locales, para evitar complicaciones con las comillas:
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$nombre = $_POST["contacto"];
$correo = $_POST["correo"];
$nombre = $_POST["contraseña"];
$apellido = $_POST["perfil"];
$correo = $_POST["deben"];

//Preparamos la orden SQL
$persona = new formularioPersona($nombre,$apellido,$contacto,$correo,$contraseña,$perfil,$deben);
 $persona->guardar2();
 echo $persona->getNombre() . ' se ha guardado correctamente con el id: ' . $persona->getId() .'<br/>';


//Aqui ejecutaremos esa orden

} else {

echo '<p>Por favor, complete el <a href="index.html">formulario</a></p>';
}

?>