<?php
 require_once 'Instancia.php';
 $fut = Jugador::recuperarTodos();
 $demy = Directivos::recuperarTodos();
?>
<?php

require_once 'instancia.php';

$persona=new Jugador('Pepito','Perez16');
$persona-> guardar();
// echo $persona ->getNombre().' se ha guardado correctamente con el id:' .$persona ->getId();

?>

<?php

require_once 'instancia.php';

$persona=new Directivos('Pepito','Perez16');
$persona-> guardar();
// echo $persona ->getNombre().' se ha guardado correctamente con el id:' .$persona ->getId();

?>


<html>
   <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="jquery.dynamicTable.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="style.css" type="text/css" rel="stylesheet">
    </head>
    
   <body>
     <!--
      <ul>
      <?php foreach($jugador as $item): ?>
      <li> <?php echo $item['Id'] . ' - ' . $item['Nombre'] . ' - ' . $item['Apellido']; ?> </li>
      <?php endforeach; ?>
      </ul>
   -->
   

   <h4 class="titulo">PSICOLAB</h4>
<div style="width: 100%">


    <div style="display: flex; margin: 5px" >
        <div class="isCanvas">
        <canvas id="myChart" width="400" height="400"></canvas>
        </div>

         <div class="isCanvas">
         <canvas id="Dos" width="400" height="400"></canvas> 
         </div>
    </div>

    <div style="display: flex;">
        <div class="isCanvas">
        <canvas id="uno" width="400" height="400" background="blue"></canvas>
        </div>
        <div class="isCanvas">
        <canvas id="tres" width="400" height="400"></canvas> 
        </div>
    </div>

  </div>



<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>



<script>
const Dos = document.getElementById('myChart').getContext('2d');

const mychar = new Chart(Dos, {
type: 'polarArea',
data: {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'
       
    ],
    datasets: [{
        label: 'Personas registradas',
        data: [   
            <?php foreach($fut as $item):?>
        <?php echo $item['Id'];?>, 
        <?php endforeach; ?>
        ],
        backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
    }]
},
options: {
    scales: {
        y: {
            beginAtZero: true
        }
    }
}
});

</script>




<script>
const hola = document.getElementById('uno').getContext('2d');

const mycharuno = new Chart(hola, {
type: 'line',
data: {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
        label: '# of Votes',
        data: [<?php foreach($fut as $item):?>
        <?php echo $item['Id'];?>, 
        <?php endforeach; ?>],
        backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
    }]
},
options: {
    scales: {
        y: {
            beginAtZero: true
        }
    }
}
});

</script>




<script>
const holatres = document.getElementById('tres').getContext('2d');

const mycharunotres = new Chart(holatres, {
type: 'radar',
data: {
    labels: ['Blue', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
        label: '# of Votes',
        data: [<?php foreach($fut as $item):?>
        <?php echo $item['Id'];?>, 
        <?php endforeach; ?>],
        backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
    }]
},
options: {
    scales: {
        y: {
            beginAtZero: true
        }
    }
}
});

</script>





<script>
const Uno = document.getElementById('Dos').getContext('2d');


const mychartDos = new Chart(Uno, {
type: 'doughnut',
data: {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
        label: '# of Votes',
        data: [<?php foreach($fut as $item):?>
        <?php echo $item['Id'];?>, 
        <?php endforeach; ?>],
        backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
    }]
},
options: {
    scales: {
        y: {
            beginAtZero: true
        }
    }
}
});
</script>