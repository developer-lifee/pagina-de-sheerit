<?php
header('Content-Type: text/html; charset=UTF-8');
 require_once 'conexion.php';
 class formularioPersona {
   private $id;
   private $nombre;
   private $apellido;
   private $contacto;
   private $correo;
   private $contraseña;
   private $perfil;
   private $deben;
   const TABLA = 'elneflis';

   public function getId() {
      return $this->id;
   }

   public function getNombre() {
      return $this->nombre;
   }
   public function getApellido() {
      return $this->apellido;
   }
   public function getContacto() {
      return $this->contacto;
   }
   public function getCorreo() {
    return $this->correo;
 }
 public function getContraseña() {
   return $this->contraseña;
}
public function getPerfil() {
   return $this->perfil;
}
public function getDeben() {
   return $this->deben;
}
   public function setNombre($nombre) {
      $this->nombre = $nombre;
   }
   public function setApellido($apellido) {
      $this->apellido = $apellido;
   }
   public function setContacto($contacto) {
      $this->contacto = $contacto;
   }
   public function setCorreo($correo) {
    $this->correo = $correo;
 }
 public function setContraseña($contraseña) {
   $this->contraseña = $contraseña;
}
public function setPerfil($perfil) {
   $this->perfil = $perfil;
}
public function setDeben($deben) {
   $this->deben = $deben;
}
   public function __construct($nombre, $apellido,$correo, $id=null) {
      $this->nombre = $nombre;
      $this->correo = $correo;
      $this->apellido = $apellido;
      $this->id = $id;
   }
   public function guardar(){
      $conexion = new Conexion();
{
   $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (Nombre, Apellido, Contacto, Correo, Contraseña, Perfil, Deben) VALUES(:nombre, :apellido, :contacto, :correo, :contraseña, :perfil, :deben)');
   $consulta->bindParam(':nombre', $this->nombre);
   $consulta->bindParam(':apellido', $this->apellido);
   $consulta->bindParam(':contacto', $this->contacto);
   $consulta->bindParam(':correo', $this->correo);
   $consulta->bindParam(':contraseña', $this->contraseña);
   $consulta->bindParam(':perfil', $this->perfil);
   $consulta->bindParam(':deben', $this->deben);
   $consulta->execute();
   $this->id = $conexion->lastInsertId();
}
      $conexion = null;
   }
   public static function recuperarTodos(){
      $conexion = new Conexion();
      $consulta = $conexion->prepare('SELECT Id, Nombre, Apellido, Contacto, Correo, Contraseña, Perfil, Deben FROM ' . self::TABLA . ' ORDER BY Nombre');
      $consulta->execute();
      $registros = $consulta->fetchAll();
      return $registros;
   }
 }
