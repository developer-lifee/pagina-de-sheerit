<?php
 require_once 'Instancia2.php';
 
 $persona = new formularioPersona ('netflix', 'Mayha', 'Mayha', 'martha', 'yuliplay688@gmail.com', '181818', '525', '2022-10-09 00:00:00');
 $persona->guardar2();
 echo $persona->getNombre() . ' se ha guardado correctamente con el id: ' . $persona->getId() .'<br/>';

 
?>